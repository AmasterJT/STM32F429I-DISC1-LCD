
#ifndef JUEGOSCARACTERES_JUEGOALPHA17_H_
#define JUEGOSCARACTERES_JUEGOALPHA17_H_

#include <pantallaLCD.h>
#include <stdint.h>

extern const LCD_JuegoCaracteresAlpha juegoAlpha17;

#endif /* JUEGOSCARACTERES_JUEGOALPHA17_H_ */
