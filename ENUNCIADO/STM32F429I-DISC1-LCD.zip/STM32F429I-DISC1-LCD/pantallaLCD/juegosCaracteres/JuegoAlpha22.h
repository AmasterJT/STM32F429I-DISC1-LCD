
#ifndef JUEGOSCARACTERES_JUEGOALPHA22_H_
#define JUEGOSCARACTERES_JUEGOALPHA22_H_

#include <pantallaLCD.h>
#include <stdint.h>

extern const LCD_JuegoCaracteresAlpha juegoAlpha22;

#endif /* JUEGOSCARACTERES_JUEGOALPHA22_H_ */
