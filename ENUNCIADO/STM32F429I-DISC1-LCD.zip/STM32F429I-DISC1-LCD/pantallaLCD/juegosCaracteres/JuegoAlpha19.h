
#ifndef JUEGOSCARACTERES_JUEGOALPHA19_H_
#define JUEGOSCARACTERES_JUEGOALPHA19_H_

#include <pantallaLCD.h>
#include <stdint.h>

extern const LCD_JuegoCaracteresAlpha juegoAlpha19;

#endif /* JUEGOSCARACTERES_JUEGOALPHA19_H_ */
