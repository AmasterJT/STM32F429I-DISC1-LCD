
#ifndef JUEGOSCARACTERES_JUEGOALPHA13_H_
#define JUEGOSCARACTERES_JUEGOALPHA13_H_

#include <pantallaLCD.h>
#include <stdint.h>

extern const LCD_JuegoCaracteresAlpha juegoAlpha13;

#endif /* JUEGOSCARACTERES_JUEGOALPHA13_H_ */
