
#ifndef JUEGOSCARACTERES_JUEGOALPHA15_H_
#define JUEGOSCARACTERES_JUEGOALPHA15_H_

#include <pantallaLCD.h>
#include <stdint.h>

extern const LCD_JuegoCaracteresAlpha juegoAlpha15;

#endif /* JUEGOSCARACTERES_JUEGOALPHA15_H_ */
